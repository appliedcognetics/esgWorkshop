﻿

Write-Host("Replacing web ui settings...")

$replace_webapp_ui_name = $webapp_ui_name
$replace_webapp_backendapi_name = $webapp_backendapi_name
$replace_clientid = $webapp_ui_clientid
$replace_tenantid = $webapp_ui_tenantid
$files = Get-ChildItem -path $webapp_ui_codepath

Add-Type -Assembly  System.IO.Compression.FileSystem
$ErrorActionPreference = 'Stop'

$fileToEdit  = "*.js"
$fileToEdit1  = "web.config"
$newContext=""

foreach ($file in $files) {
    try {
        Write-Host("file "+$file.Name)
        $zip = [System.IO.Compression.ZipFile]::Open($file, "Update")
        $entries = $zip.Entries.Where({ $_.Name -like $fileToEdit -or $fileToEdit1 })
        foreach($entry in $entries) {
            if(!$entry.Name.Contains(".js") -and !$entry.Name.Contains(".config"))
            {
            Write-Host("!! $entry")
                continue
            }
            Write-Host("entries ****** $entry")
            $reader  = [System.IO.StreamReader]::new($entry.Open())
            $content=$reader.ReadToEnd()
            $newContext=$content
            $reader.Close()
            $reader.Dispose()
            Write-Host("***content..  $entry")
            $newContext=$newContext.Replace("{replace_webapp_ui_name}", $replace_webapp_ui_name)
            $newContext=$newContext.Replace("{replace_webapp_backendapi_name}", $replace_webapp_backendapi_name)            
            $newContext=$newContext.Replace("{replace_clientid}", $replace_clientid)
            $newContext=$newContext.Replace("{replace_tenantid}", $replace_tenantid)
            $writer  = [System.IO.StreamWriter]::new($entry.Open())
            $writer.BaseStream.SetLength(0)
            $writer.Write($newContext)
            Write-Host("content write completed")
            $writer.Close()
            $writer.Dispose()
        }
    }
    catch {
        Write-Warning $_.Exception.Message
        continue
    }
    finally {
        if($zip) {
            $zip.Dispose()
        }
    }
}

Write-Host("File replace value from zip file completed..")
